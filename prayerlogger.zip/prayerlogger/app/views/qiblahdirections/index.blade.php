@extends('layouts.main')


@section('tablinks')

<li><a href="homes">Home</a></li>
<li><a href="prayerlogs">Prayer Book</a></li>
<li><a href="prayers">Prayer Timing</a></li>
<li><a href="mosques">Mosque Finding</a></li>
<li class="active"><a href="qiblahdirections">Qiblah Direction</a></li>
<li><a href="settings">Settings</a></li>

@stop