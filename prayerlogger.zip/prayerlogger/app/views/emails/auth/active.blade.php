<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        <h2>Verify Your Email Address</h2>

        <div>
            hello {{$name}}
            Aslam-o-Alakum<br/>
            Please follow the link below to verify your email address.<br/><br/>
            ---<br/>
            {{ $link, $code }}.<br/>

        </div>

    </body>
</html>